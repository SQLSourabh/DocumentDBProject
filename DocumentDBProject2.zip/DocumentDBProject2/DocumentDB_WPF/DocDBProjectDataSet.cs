﻿namespace DocumentDB_WPF {
    
    
    public partial class DocDBProjectDataSet {
        partial class ProductInfoDataTable
        {
        }
    
        partial class ProductInfo1DataTable
        {
        }
    }
}
